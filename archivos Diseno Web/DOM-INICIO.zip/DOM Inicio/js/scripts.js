(function(){
  'use strict';
  document.addEventListener('DOMContentLoaded', function(){
    
    
      
      
    
    
  });
  
})();